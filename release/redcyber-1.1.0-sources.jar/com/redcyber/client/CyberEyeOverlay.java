package com.redcyber.client;

import com.redcyber.core.CyberSlot;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_7923;

/**
 * «Визор» кибернетического глаза.
 *
 * Это не ночное зрение: поверх мира рисуется интерфейс оптики — тёмная виньетка,
 * сканлайны, бегущая строка развёртки, уголки-рамки, прицел и телеметрия по цели.
 * Включается только когда имплант глаза установлен и не отключён в меню тумблеров.
 */
public final class CyberEyeOverlay implements HudRenderCallback {
    private static final int GREEN = 0xFF6FF7C8;
    private static final int GREEN_DIM = 0xB03AD9A6;
    private static final int CYAN = 0xFF7FE4FF;
    private static final int DARK = 0xFF04120C;

    private CyberEyeOverlay() {
    }

    public static void register() {
        HudRenderCallback.EVENT.register(new CyberEyeOverlay());
    }

    @Override
    public void onHudRender(class_332 context, net.minecraft.class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1690.field_1842) {
            return;
        }
        if (client.field_1755 != null) {
            return;
        }
        if (!ClientCyberData.isEnabled(CyberSlot.EYE)) {
            return;
        }

        int w = context.method_51421();
        int h = context.method_51443();
        long time = client.field_1687.method_8510();

        drawVignette(context, w, h);
        drawScanlines(context, w, h, time);
        drawSweep(context, w, h, time);
        drawReticle(context, w, h, time);
        drawTelemetry(client, context, w, h);
    }

    // ------------------------------------------------------------------
    //  Элементы визора
    // ------------------------------------------------------------------

    private static void drawVignette(class_332 context, int w, int h) {
        int edge = Math.max(16, h / 10);
        context.method_25296(0, 0, w, edge, 0xE004120C, 0x0004120C);
        context.method_25296(0, h - edge, w, h, 0x0004120C, 0xE004120C);
        context.method_25294(0, edge, 12, h - edge, 0x3004120C);
        context.method_25294(w - 12, edge, w, h - edge, 0x3004120C);

        // уголки-рамки
        int arm = 22;
        int thick = 2;
        int pad = edge - 6;
        // левый верхний
        context.method_25294(pad, pad, pad + arm, pad + thick, GREEN_DIM);
        context.method_25294(pad, pad, pad + thick, pad + arm, GREEN_DIM);
        // правый верхний
        context.method_25294(w - pad - arm, pad, w - pad, pad + thick, GREEN_DIM);
        context.method_25294(w - pad - thick, pad, w - pad, pad + arm, GREEN_DIM);
        // левый нижний
        context.method_25294(pad, h - pad - thick, pad + arm, h - pad, GREEN_DIM);
        context.method_25294(pad, h - pad - arm, pad + thick, h - pad, GREEN_DIM);
        // правый нижний
        context.method_25294(w - pad - arm, h - pad - thick, w - pad, h - pad, GREEN_DIM);
        context.method_25294(w - pad - thick, h - pad - arm, w - pad, h - pad, GREEN_DIM);
    }

    private static void drawScanlines(class_332 context, int w, int h, long time) {
        for (int y = 4; y < h; y += 4) {
            // лёгкое «дыхание» интенсивности, чтобы картинка не была статичной
            int alpha = (((y / 4) + (int) (time / 3)) % 8 == 0) ? 0x1E : 0x10;
            context.method_25294(0, y, w, y + 1, (alpha << 24) | 0x0BFFB4);
        }
    }

    private static void drawSweep(class_332 context, int w, int h, long time) {
        int y = (int) ((time * 6) % (h + 60)) - 30;
        if (y < 0 || y > h) {
            return;
        }
        context.method_25296(0, Math.max(0, y - 10), w, y, 0x0000FFC8, 0x2200FFC8);
        context.method_25294(0, y, w, y + 1, 0x6600FFC8);
    }

    private static void drawReticle(class_332 context, int w, int h, long time) {
        int cx = w / 2;
        int cy = h / 2;
        int gap = 5;
        int arm = 12;
        int pulse = (int) (0.5 + 0.5 * Math.sin(time * 0.15));

        // крест с разрывом
        context.method_25294(cx - gap - arm, cy, cx - gap, cy + 1, GREEN);
        context.method_25294(cx + gap, cy, cx + gap + arm, cy + 1, GREEN);
        context.method_25294(cx, cy - gap - arm, cx + 1, cy - gap, GREEN);
        context.method_25294(cx, cy + gap, cx + 1, cy + gap + arm, GREEN);

        // пульсирующая рамка вокруг цели
        int box = 9 + pulse;
        context.method_25294(cx - box, cy - box, cx + box, cy - box + 1, GREEN_DIM);
        context.method_25294(cx - box, cy + box, cx + box, cy + box + 1, GREEN_DIM);
        context.method_25294(cx - box, cy - box, cx - box + 1, cy + box, GREEN_DIM);
        context.method_25294(cx + box, cy - box, cx + box + 1, cy + box, GREEN_DIM);

        // «уровень» по горизонту
        int lineY = h / 2 + h / 6;
        context.method_25294(cx - 40, lineY, cx - 8, lineY + 1, 0x8045F2BE);
        context.method_25294(cx + 8, lineY, cx + 40, lineY + 1, 0x8045F2BE);
    }

    private static void drawTelemetry(class_310 client, class_332 context, int w, int h) {
        class_327 tr = client.field_1772;
        int edge = Math.max(16, h / 10);
        int x = edge + 6;
        int y = edge + 4;

        context.method_27535(tr, class_2561.method_43470("OPTIC // RC-EYE 1.1"), x, y, GREEN);
        context.method_27535(tr, class_2561.method_43470("SCAN MODE: ACTIVE"), x, y + 11, GREEN_DIM);

        String target = targetInfo(client);
        if (target != null) {
            context.method_27535(tr, class_2561.method_43470(target), x, y + 24, CYAN);
        }

        if (client.field_1724 != null) {
            String pos = String.format("POS %.0f %.0f %.0f",
                    client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
            context.method_27535(tr, class_2561.method_43470(pos), w - tr.method_1727(pos) - edge - 6, edge + 4, GREEN_DIM);
            String hp = String.format("VIT %d%%",
                    Math.round(100.0f * client.field_1724.method_6032() / Math.max(1.0f, client.field_1724.method_6063())));
            context.method_27535(tr, class_2561.method_43470(hp), w - tr.method_1727(hp) - edge - 6, edge + 15, GREEN_DIM);
        }
    }

    /** Что в прицеле: блок или существо, и на какой дистанции. */
    private static String targetInfo(class_310 client) {
        class_239 hit = client.field_1765;
        if (client.field_1724 == null || hit == null) {
            return null;
        }
        double dist = hit.method_17784().method_1022(client.field_1724.method_33571());
        if (hit instanceof class_3965 blockHit) {
            if (client.field_1687 == null) {
                return null;
            }
            var state = client.field_1687.method_8320(blockHit.method_17777());
            String name = state.method_26204().method_9518().getString();
            return String.format("%s  %.1fm  [%d %d %d]", name, dist,
                    blockHit.method_17777().method_10263(), blockHit.method_17777().method_10264(), blockHit.method_17777().method_10260());
        }
        if (hit instanceof class_3966 entityHit) {
            class_1297 entity = entityHit.method_17782();
            String name = entity.method_5477().getString();
            return String.format("%s  %.1fm", name, dist);
        }
        if (hit.method_17783() == class_239.class_240.field_1332) {
            return String.format("BLOCK  %.1fm", dist);
        }
        return null;
    }

    /** Не используется, но оставлено для проверки регистрации предметов в телеметрии. */
    @SuppressWarnings("unused")
    private static String itemName(class_1799 stack) {
        return class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
    }
}
