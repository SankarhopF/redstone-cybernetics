package com.redcyber.client;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5498;

/**
 * Фиксированная камера операции.
 *
 * Камера <b>не зависит</b> от того, куда смотрит игрок: она всегда стоит со стороны
 * ножного конца стола, слева от пациента и чуть выше его, и смотрит на лежащего.
 * Положение считается от центра лежащего и оси тела (yaw сессии), см.
 * {@code CameraMixin}.
 */
public final class CameraRig {
    /** Насколько камера отходит назад — в сторону ног. */
    private static final double BACK_OFFSET = 1.05;
    /** Смещение влево от пациента (влево = по левую руку смотрящего от ног к голове). */
    private static final double SIDE_OFFSET = 1.30;
    /** Высота камеры над лежащим. */
    private static final double HEIGHT_OFFSET = 1.45;
    /** Точка прицеливания смещена чуть к голове и на уровень груди. */
    private static final double AIM_FORWARD = 0.20;
    private static final double AIM_HEIGHT = 0.45;

    private static class_5498 saved = null;

    private CameraRig() {
    }

    public static void enterThirdPerson() {
        class_310 client = class_310.method_1551();
        if (saved == null) {
            saved = client.field_1690.method_31044();
        }
        // Камеру всё равно переопределяет CameraMixin; режим нужен только для того,
        // чтобы игра рисовала модель самого игрока.
        client.field_1690.method_31043(class_5498.field_26665);
    }

    public static void restore() {
        class_310 client = class_310.method_1551();
        if (saved != null) {
            client.field_1690.method_31043(saved);
            saved = null;
        }
    }

    /** Позиция камеры в мире. */
    public static class_243 cameraPos(class_243 focus, float yawDeg) {
        class_243 forward = forward(yawDeg);
        class_243 left = new class_243(forward.field_1350, 0.0, -forward.field_1352);
        return focus.method_1019(forward.method_1021(-BACK_OFFSET))
                .method_1019(left.method_1021(SIDE_OFFSET))
                .method_1031(0.0, HEIGHT_OFFSET, 0.0);
    }

    /** Точка, на которую смотрит камера (грудь пациента). */
    public static class_243 aimPos(class_243 focus, float yawDeg) {
        class_243 forward = forward(yawDeg);
        return focus.method_1019(forward.method_1021(AIM_FORWARD)).method_1031(0.0, AIM_HEIGHT, 0.0);
    }

    /** Горизонтальное направление оси тела по yaw игрока. */
    private static class_243 forward(float yawDeg) {
        double rad = Math.toRadians(yawDeg);
        return new class_243(-Math.sin(rad), 0.0, Math.cos(rad));
    }
}
