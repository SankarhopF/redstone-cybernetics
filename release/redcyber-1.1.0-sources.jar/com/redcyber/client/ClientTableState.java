package com.redcyber.client;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_310;

/**
 * Клиентское состояние «игрок лежит на операционном столе».
 *
 * Пока оно активно: включено третье лицо, стол подсвечен, камера жёстко
 * зафиксирована у стола (см. {@link CameraRig}), а модель персонажа
 * проигрывает анимации из PlayerAnimator.
 */
public final class ClientTableState {
    private static boolean active = false;
    private static class_2338 tablePos = null;
    private static float sessionYaw = 0.0f;

    private ClientTableState() {
    }

    public static void begin(class_2338 pos, float yaw) {
        active = true;
        tablePos = pos == null ? null : pos.method_10062();
        sessionYaw = yaw;
    }

    public static void end() {
        active = false;
        tablePos = null;
        sessionYaw = 0.0f;
    }

    public static boolean active() {
        return active;
    }

    public static class_2338 tablePos() {
        return tablePos;
    }

    /** Yaw лежащего игрока в момент начала сессии — ось «ноги-голова». */
    public static float sessionYaw() {
        return sessionYaw;
    }

    /** Лежит ли на столе именно это существо (нужно рендереру для масштаба модели). */
    public static boolean isLying(class_1297 entity) {
        if (!active) {
            return false;
        }
        class_310 client = class_310.method_1551();
        return client.field_1724 != null && client.field_1724 == entity;
    }
}
