package com.redcyber.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Клавиши мода. Меню тумблеров открывается удержанием клавиши. */
public final class ModKeybinds {
    /** Удержание этой клавиши открывает меню отключения возможностей кибернетики. */
    public static final class_304 ABILITIES = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.redcyber.abilities",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_G,
            "key.categories.redcyber"));

    private ModKeybinds() {
    }

    /** Регистрация происходит в статическом инициализаторе; метод задаёт порядок. */
    public static void init() {
    }
}
