package com.redcyber.client.screen;

import com.redcyber.client.ClientCyberData;
import com.redcyber.core.CyberPart;
import com.redcyber.core.CyberSlot;
import com.redcyber.net.ModPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Меню отключения дополнительных возможностей кибернетики.
 *
 * Открывается удержанием клавиши (по умолчанию G). Фон размывается, панель
 * остаётся чёткой. Каждый установленный имплант можно включить или выключить —
 * состояние сохраняется на сервере и влияет на эффекты и атрибуты.
 */
public class AbilityScreen extends class_437 {
    private static final int PANEL_W = 320;
    private static final int ROW_H = 26;

    private static final int COL_PANEL = 0xF01B2027;
    private static final int COL_BORDER = 0xFF39424D;
    private static final int COL_ACCENT = 0xFFE02231;
    private static final int COL_TEXT = 0xFFF2F5F7;
    private static final int COL_MUTED = 0xFF97A1AC;

    private final List<CyberSlot> slots = new ArrayList<>();
    private final Map<CyberSlot, class_4185> buttons = new EnumMap<>(CyberSlot.class);

    private int panelX;
    private int panelY;
    private int panelH;

    public AbilityScreen() {
        super(class_2561.method_43471("redcyber.screen.abilities.title"));
    }

    @Override
    protected void method_25426() {
        this.slots.clear();
        this.slots.addAll(ClientCyberData.all().keySet());
        this.slots.sort(Comparator.comparingInt(Enum::ordinal));
        this.buttons.clear();

        int rows = Math.max(1, this.slots.size());
        this.panelH = 64 + rows * ROW_H + 28;
        this.panelX = (this.field_22789 - PANEL_W) / 2;
        this.panelY = (this.field_22790 - this.panelH) / 2;

        int rowY = this.panelY + 52;
        for (int i = 0; i < this.slots.size(); i++) {
            CyberSlot slot = this.slots.get(i);
            class_4185 button = class_4185
                    .method_46430(this.labelFor(slot), b -> this.toggle(slot))
                    .method_46434(this.panelX + PANEL_W - 96, rowY + i * ROW_H + 3, 84, 20)
                    .method_46431();
            this.buttons.put(slot, button);
            this.method_37063(button);
        }

        this.method_37063(class_4185
                .method_46430(class_2561.method_43471("redcyber.screen.abilities.close"), b -> this.method_25419())
                .method_46434(this.panelX + (PANEL_W - 120) / 2, this.panelY + this.panelH - 26, 120, 20)
                .method_46431());
    }

    private class_2561 labelFor(CyberSlot slot) {
        boolean enabled = !ClientCyberData.isDisabled(slot);
        return class_2561.method_43471(enabled ? "redcyber.screen.abilities.on" : "redcyber.screen.abilities.off")
                .method_27692(enabled ? class_124.field_1060 : class_124.field_1061);
    }

    private void toggle(CyberSlot slot) {
        boolean enable = ClientCyberData.isDisabled(slot);
        ClientCyberData.setLocallyEnabled(slot, enable);
        if (ClientPlayNetworking.canSend(ModPackets.ToggleAbilityC2S.ID)) {
            ClientPlayNetworking.send(new ModPackets.ToggleAbilityC2S(slot.key(), enable));
        }
        class_4185 button = this.buttons.get(slot);
        if (button != null) {
            button.method_25355(this.labelFor(slot));
        }
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_57734(delta);
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0xA0000000, 0xD0000000);

        int x = this.panelX;
        int y = this.panelY;
        context.method_25294(x - 3, y - 3, x + PANEL_W + 3, y + this.panelH + 3, 0x80000000);
        context.method_25294(x, y, x + PANEL_W, y + this.panelH, COL_PANEL);
        context.method_49601(x, y, PANEL_W, this.panelH, COL_BORDER);
        context.method_25294(x, y, x + PANEL_W, y + 3, COL_ACCENT);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        class_327 tr = this.field_22793;
        int x = this.panelX;
        int y = this.panelY;

        context.method_51439(tr, class_2561.method_43471("redcyber.screen.abilities.title"), x + 12, y + 12, COL_TEXT, false);
        context.method_51439(tr, class_2561.method_43471("redcyber.screen.abilities.subtitle"), x + 12, y + 26, COL_MUTED, false);
        context.method_25294(x + 12, y + 40, x + PANEL_W - 12, y + 41, COL_BORDER);

        if (this.slots.isEmpty()) {
            context.method_51439(tr, class_2561.method_43471("redcyber.screen.abilities.empty"),
                    x + 12, y + 56, COL_MUTED, false);
            return;
        }

        int rowY = y + 52;
        for (int i = 0; i < this.slots.size(); i++) {
            CyberSlot slot = this.slots.get(i);
            int ry = rowY + i * ROW_H;
            context.method_25294(x + 12, ry, x + PANEL_W - 12, ry + ROW_H - 2, 0xFF1A1F26);

            var part = ClientCyberData.installedIn(slot);
            if (part != null) {
                context.method_51427(part.item().method_7854(), x + 16, ry + 5);
                context.method_51439(tr, part.item().method_7848(), x + 38, ry + 4, COL_TEXT, false);
            } else {
                context.method_51439(tr, slot.displayName(), x + 38, ry + 4, COL_TEXT, false);
            }
            context.method_51439(tr, slot.displayName(), x + 38, ry + 14, COL_MUTED, false);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(null);
    }
}
