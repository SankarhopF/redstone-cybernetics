package com.redcyber.client.screen;

import com.redcyber.core.CyberPart;
import com.redcyber.core.CyberParts;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_746;

/**
 * Кинематографичная анимация замены части тела.
 *
 * Мир остаётся видимым (камера в третьем лице смотрит на лежащего персонажа),
 * сверху накладываются кинематографические полосы, прогресс операции, искры
 * редстоуна и «судороги» собеседника (анимация модели — в PlayerEntityModelMixin).
 */
public class SurgeryScreen extends class_437 {
    private final String partName;
    private final int duration;
    private int ticks = 0;
    private int lastPhase = -1;

    public SurgeryScreen(String partName, int duration) {
        super(class_2561.method_43471("redcyber.screen.surgery.title"));
        this.partName = partName;
        this.duration = Math.max(1, duration);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    /** Фон не рисуем: игрок должен видеть операцию на персонаже. */
    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void method_25393() {
        super.method_25393();
        this.ticks++;
        this.emitEffects();

        // Страховка: если сервер почему-то не прислал конец операции — выходим сами.
        if (this.ticks > this.duration + 100) {
            class_310 client = class_310.method_1551();
            client.method_1507(null);
            com.redcyber.client.CameraRig.restore();
            com.redcyber.client.ClientSurgeryState.clear();
        }
    }

    private float progress() {
        return class_3532.method_15363(this.ticks / (float) this.duration, 0.0f, 1.0f);
    }

    private int phase() {
        float p = this.progress();
        if (p < 0.15f) {
            return 0;
        }
        if (p < 0.35f) {
            return 1;
        }
        if (p < 0.68f) {
            return 2;
        }
        if (p < 0.9f) {
            return 3;
        }
        return 4;
    }

    private static final String[] PHASES = {
            "redcyber.screen.surgery.phase.anesthesia",
            "redcyber.screen.surgery.phase.incision",
            "redcyber.screen.surgery.phase.implant",
            "redcyber.screen.surgery.phase.wiring",
            "redcyber.screen.surgery.phase.calibration"
    };

    private void emitEffects() {
        class_310 client = class_310.method_1551();
        class_746 player = client.field_1724;
        if (player == null) {
            return;
        }

        double px = player.method_23317();
        double py = player.method_23318() + 0.35;
        double pz = player.method_23321();

        if (this.ticks % 2 == 0) {
            for (int i = 0; i < 2; i++) {
                double ox = (player.method_59922().method_43058() - 0.5) * 1.0;
                double oz = (player.method_59922().method_43058() - 0.5) * 1.0;
                double oy = (player.method_59922().method_43058() - 0.5) * 0.35;
                player.method_37908().method_8406(class_2398.field_29644,
                        px + ox, py + oy, pz + oz, 0.0, 0.015, 0.0);
            }
        }

        int phase = this.phase();
        if (phase != this.lastPhase) {
            this.lastPhase = phase;
            switch (phase) {
                case 0 -> player.method_5783(class_3417.field_14703, 0.6f, 0.6f);
                case 1 -> player.method_5783(class_3417.field_14559, 0.55f, 1.4f);
                case 2 -> player.method_5783(class_3417.field_15134, 0.8f, 1.1f);
                case 3 -> player.method_5783(class_3417.field_23116, 0.85f, 1.5f);
                default -> player.method_5783(class_3417.field_14891, 0.7f, 1.2f);
            }
        }
        if (this.ticks % 10 == 5) {
            player.method_5783(class_3417.field_19199, 0.25f, 1.9f);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        class_327 tr = this.field_22793;
        int w = this.field_22789;
        int h = this.field_22790;
        int barH = 32;

        // Кинематографические полосы
        context.method_25294(0, 0, w, barH, 0xC4000000);
        context.method_25294(0, h - barH, w, h, 0xC4000000);

        // Пульсирующее красное свечение сверху/снизу
        int pulse = (int) (70 + 45 * (0.5 + 0.5 * class_3532.method_15374(this.ticks * 0.32f)));
        int glow = (pulse << 24) | 0xB3121B;
        context.method_25296(0, barH, w, barH + 70, glow, 0x00B3121B);
        context.method_25296(0, h - barH - 70, w, h - barH, 0x00B3121B, glow);

        // Заголовок и иконка импланта
        CyberPart part = CyberParts.byName(this.partName);
        class_2561 title = class_2561.method_43471("redcyber.screen.surgery.title").method_27692(class_124.field_1067);
        int titleW = tr.method_27525(title);
        int titleY = 8;
        context.method_51439(tr, title, (w - titleW) / 2, titleY, 0xFFE02231, true);
        class_2561 sub = class_2561.method_43469("redcyber.screen.surgery.target",
                part == null ? class_2561.method_43470(this.partName) : part.item().method_7848());
        context.method_27534(tr, sub, w / 2, titleY + 11, 0xFFF2F5F7);
        if (part != null) {
            context.method_51427(new class_1799(part.item()), (w - titleW) / 2 - 24, titleY - 2);
        }

        // Прогресс
        int pbW = 220;
        int pbX = (w - pbW) / 2;
        int pbY = h - barH - 40;
        context.method_25294(pbX - 1, pbY - 1, pbX + pbW + 1, pbY + 9, 0xFF000000);
        context.method_25294(pbX, pbY, pbX + pbW, pbY + 8, 0xFF2A3138);
        context.method_25294(pbX, pbY, pbX + (int) (pbW * this.progress()), pbY + 8, 0xFFE02231);
        context.method_25294(pbX, pbY, pbX + (int) (pbW * this.progress()), pbY + 2, 0xFFFF6B4A);

        context.method_27534(tr, class_2561.method_43471(PHASES[this.phase()]), w / 2, pbY - 14, 0xFFF2F5F7);
        class_2561 percent = class_2561.method_43470((int) (this.progress() * 100) + "%");
        context.method_27534(tr, percent, w / 2, pbY + 13, 0xFF97A1AC);

        // Подсказка
        context.method_27534(tr, class_2561.method_43471("redcyber.screen.surgery.hold_still"),
                w / 2, h - barH + 11, 0x9AF2F5F7);
    }
}
