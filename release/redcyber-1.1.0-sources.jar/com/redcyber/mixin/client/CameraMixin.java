package com.redcyber.mixin.client;

import com.redcyber.client.CameraRig;
import com.redcyber.client.ClientTableState;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Жёстко ставит камеру у операционного стола, полностью игнорируя то, куда смотрит
 * игрок: со стороны ног, слева и чуть выше, с прицелом на лежащего пациента.
 */
@Mixin(class_4184.class)
public abstract class CameraMixin {

    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V",
            at = @At("TAIL"))
    private void redcyber$tableCamera(class_1922 area, class_1297 focusedEntity, boolean thirdPerson,
                                      boolean inverseView, float tickDelta, CallbackInfo ci) {
        if (!ClientTableState.active()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || focusedEntity != client.field_1724) {
            return;
        }

        class_243 focus = focusedEntity.method_30950(tickDelta);
        float bodyYaw = ClientTableState.sessionYaw();
        class_243 cam = CameraRig.cameraPos(focus, bodyYaw);
        class_243 aim = CameraRig.aimPos(focus, bodyYaw);

        class_243 dir = aim.method_1020(cam);
        double len = dir.method_1033();
        if (len < 1.0E-4) {
            return;
        }
        dir = dir.method_1021(1.0 / len);

        float yaw = (float) Math.toDegrees(Math.atan2(-dir.field_1352, dir.field_1350));
        float pitch = (float) -Math.toDegrees(Math.asin(dir.field_1351));

        this.setPos(cam.field_1352, cam.field_1351, cam.field_1350);
        this.setRotation(yaw, pitch);
    }
}
