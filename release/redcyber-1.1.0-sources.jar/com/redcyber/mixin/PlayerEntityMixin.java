package com.redcyber.mixin;

import com.redcyber.core.CyberAccess;
import com.redcyber.core.CyberSlot;
import com.redcyber.core.SurgeryManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

/**
 * Хранит установленные импланты в NBT игрока и держит игрока лежащим на столе,
 * пока открыта сессия операции.
 */
@Mixin(class_1657.class)
public abstract class PlayerEntityMixin implements CyberAccess {
    @Unique
    private Map<CyberSlot, String> redcyber$parts;

    @Unique
    private Set<CyberSlot> redcyber$disabled;

    @Override
    public Map<CyberSlot, String> redcyber$getParts() {
        if (this.redcyber$parts == null) {
            this.redcyber$parts = new EnumMap<>(CyberSlot.class);
        }
        return this.redcyber$parts;
    }

    @Override
    public Set<CyberSlot> redcyber$getDisabled() {
        if (this.redcyber$disabled == null) {
            this.redcyber$disabled = EnumSet.noneOf(CyberSlot.class);
        }
        return this.redcyber$disabled;
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void redcyber$writeNbt(class_2487 nbt, CallbackInfo ci) {
        class_2487 tag = new class_2487();
        this.redcyber$getParts().forEach((slot, part) -> tag.method_10582(slot.lowerName(), part));
        nbt.method_10566("RedCyberParts", tag);

        class_2499 off = new class_2499();
        for (CyberSlot slot : this.redcyber$getDisabled()) {
            off.add(class_2519.method_23256(slot.lowerName()));
        }
        nbt.method_10566("RedCyberDisabled", off);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void redcyber$readNbt(class_2487 nbt, CallbackInfo ci) {
        Map<CyberSlot, String> parts = this.redcyber$getParts();
        parts.clear();
        if (nbt.method_10573("RedCyberParts", class_2520.field_33260)) {
            class_2487 tag = nbt.method_10562("RedCyberParts");
            for (CyberSlot slot : CyberSlot.values()) {
                String value = tag.method_10558(slot.lowerName());
                if (!value.isEmpty()) {
                    parts.put(slot, value);
                }
            }
        }

        Set<CyberSlot> disabled = this.redcyber$getDisabled();
        disabled.clear();
        if (nbt.method_10573("RedCyberDisabled", class_2520.field_33259)) {
            class_2499 off = nbt.method_10554("RedCyberDisabled", class_2520.field_33258);
            for (int i = 0; i < off.size(); i++) {
                for (CyberSlot slot : CyberSlot.values()) {
                    if (slot.lowerName().equals(off.method_10608(i))) {
                        disabled.add(slot);
                    }
                }
            }
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void redcyber$tick(CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        if (self.method_37908().method_8608()) {
            return;
        }
        SurgeryManager.onPlayerTick(self);
    }
}
