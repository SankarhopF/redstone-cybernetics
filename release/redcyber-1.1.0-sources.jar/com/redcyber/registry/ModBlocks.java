package com.redcyber.registry;

import com.redcyber.RedCyber;
import com.redcyber.block.OperatingTableBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class ModBlocks {
    private ModBlocks() {
    }

    public static final class_2248 OPERATING_TABLE = register("operating_table",
            new OperatingTableBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.5f, 6.0f)
                    .method_9626(class_2498.field_11533)
                    .method_22488()
                    .method_9631(state -> state.method_11654(OperatingTableBlock.LIT) ? 9 : 0)));

    private static class_2248 register(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, RedCyber.id(name), block);
    }

    public static void init() {
        // Static initializer is enough; method exists for explicit ordering in RedCyber.
    }
}
