package com.redcyber.registry;

import com.redcyber.RedCyber;
import com.redcyber.core.CyberSlot;
import com.redcyber.item.ComponentItem;
import com.redcyber.item.CyberPartItem;
import com.redcyber.item.OperatingTableItem;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {
    private ModItems() {
    }

    // ---------- Редстоуновые компоненты ----------
    public static final class_1792 REDSTONE_ALLOY_INGOT = register("redstone_alloy_ingot",
            new ComponentItem(new class_1792.class_1793()));
    public static final class_1792 REDSTONE_CIRCUIT = register("redstone_circuit",
            new ComponentItem(new class_1792.class_1793()));
    public static final class_1792 REDSTONE_SERVO = register("redstone_servo",
            new ComponentItem(new class_1792.class_1793()));
    public static final class_1792 NEURAL_CHIP = register("neural_chip",
            new ComponentItem(new class_1792.class_1793()));
    public static final class_1792 POWER_CELL = register("power_cell",
            new ComponentItem(new class_1792.class_1793()));

    // ---------- Кибернетические импланты ----------
    public static final class_1792 CYBER_EYE = register("cyber_eye",
            new CyberPartItem(CyberSlot.EYE, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 CYBER_ARM = register("cyber_arm",
            new CyberPartItem(CyberSlot.ARM, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 CYBER_LEGS = register("cyber_legs",
            new CyberPartItem(CyberSlot.LEG, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 CYBER_HEART = register("cyber_heart",
            new CyberPartItem(CyberSlot.HEART, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 CYBER_LUNGS = register("cyber_lungs",
            new CyberPartItem(CyberSlot.LUNG, new class_1792.class_1793().method_7889(1)));
    public static final class_1792 CYBER_SPINE = register("cyber_spine",
            new CyberPartItem(CyberSlot.SPINE, new class_1792.class_1793().method_7889(1)));

    // ---------- Блоки ----------
    public static final class_1792 OPERATING_TABLE = register("operating_table",
            new OperatingTableItem(ModBlocks.OPERATING_TABLE, new class_1792.class_1793()));

    private static class_1792 register(String name, class_1792 item) {
        class_2960 id = RedCyber.id(name);
        return class_2378.method_10230(class_7923.field_41178, id, item);
    }

    public static void init() {
        // Static initializer is enough; method exists for explicit ordering in RedCyber.
    }
}
