package com.redcyber.registry;

import com.redcyber.RedCyber;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModItemGroups {
    private ModItemGroups() {
    }

    public static final class_5321<class_1761> MAIN = class_5321.method_29179(class_7924.field_44688,
            RedCyber.id("main"));

    public static void init() {
        class_2378.method_39197(class_7923.field_44687, MAIN, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(ModItems.POWER_CELL))
                .method_47321(class_2561.method_43471("itemGroup.redcyber.main"))
                .method_47317((context, entries) -> {
                    entries.method_45421(ModItems.REDSTONE_ALLOY_INGOT);
                    entries.method_45421(ModItems.REDSTONE_CIRCUIT);
                    entries.method_45421(ModItems.REDSTONE_SERVO);
                    entries.method_45421(ModItems.NEURAL_CHIP);
                    entries.method_45421(ModItems.POWER_CELL);
                    entries.method_45421(ModItems.OPERATING_TABLE);
                    entries.method_45421(ModItems.CYBER_EYE);
                    entries.method_45421(ModItems.CYBER_ARM);
                    entries.method_45421(ModItems.CYBER_LEGS);
                    entries.method_45421(ModItems.CYBER_HEART);
                    entries.method_45421(ModItems.CYBER_LUNGS);
                    entries.method_45421(ModItems.CYBER_SPINE);
                })
                .method_47324());
    }
}
