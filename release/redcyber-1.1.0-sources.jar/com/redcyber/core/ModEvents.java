package com.redcyber.core;

import com.redcyber.net.ModPackets;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_3222;

public final class ModEvents {
    private ModEvents() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            SurgeryManager.tick(server);

            // Раз в секунду обновляем эффекты (статус-эффекты ночного зрения и т.п.)
            if (server.method_3780() % 20 == 0) {
                for (class_3222 player : server.method_3760().method_14571()) {
                    CyberEffects.refresh(player);
                }
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();
            ModPackets.sendSync(player);
            CyberEffects.refresh(player);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            SurgeryManager.onDisconnect(handler.method_32311());
        });
    }
}
