package com.redcyber.core;

import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_2561;

/** Слоты тела, в которые ставятся кибернетические импланты. */
public enum CyberSlot {
    EYE("eye", class_124.field_1075),
    ARM("arm", class_124.field_1061),
    LEG("leg", class_124.field_1065),
    HEART("heart", class_124.field_1076),
    LUNG("lung", class_124.field_1078),
    SPINE("spine", class_124.field_1060);

    private final String key;
    private final class_124 color;

    CyberSlot(String key, class_124 color) {
        this.key = key;
        this.color = color;
    }

    public String key() {
        return this.key;
    }

    public class_124 color() {
        return this.color;
    }

    public String translationKey() {
        return "redcyber.slot." + this.key;
    }

    public class_2561 displayName() {
        return class_2561.method_43471(this.translationKey()).method_27692(this.color);
    }

    public String lowerName() {
        return this.name().toLowerCase(Locale.ROOT);
    }
}
