package com.redcyber.core;

import com.redcyber.block.OperatingTableBlock;
import com.redcyber.net.ModPackets;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4050;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Серверная логика операционного стола: игрок лежит, меню открыто, затем идёт
 * "операция" (анимацию проигрывает клиент), по завершении имплант устанавливается.
 */
public final class SurgeryManager {
    /** Длительность операции в тиках (7 секунд). */
    public static final int SURGERY_DURATION = 140;

    /** Активная сессия у стола. */
    public static final class Session {
        public final UUID playerId;
        public final class_2338 tablePos;
        public final double x;
        public final double y;
        public final double z;
        public final float yaw;

        public String partName;
        public int duration;
        public int elapsed;
        public boolean operating;

        Session(UUID playerId, class_2338 tablePos, double x, double y, double z, float yaw) {
            this.playerId = playerId;
            this.tablePos = tablePos;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();

    private SurgeryManager() {
    }

    // ------------------------------------------------------------------
    //  Лечь на стол / встать
    // ------------------------------------------------------------------

    public static boolean startSession(class_3222 player, class_2338 pos) {
        if (SESSIONS.containsKey(player.method_5667())) {
            return false;
        }
        // Стол занимает только один пациент за раз.
        for (Session other : SESSIONS.values()) {
            if (other.tablePos.equals(pos)) {
                player.method_7353(class_2561.method_43471("redcyber.msg.table_busy"), true);
                return false;
            }
        }
        class_3218 world = player.method_51469();
        class_2680 state = world.method_8320(pos);
        if (!(state.method_26204() instanceof OperatingTableBlock)) {
            return false;
        }

        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264() + OperatingTableBlock.SURFACE_HEIGHT;
        double z = pos.method_10260() + 0.5;
        // Ось тела = направление взгляда в момент использования стола.
        // Клиент ставит по ней фиксированную камеру операции (со стороны ног).
        float yaw = player.method_36454();
        float cameraPitch = 0.0f;

        Session session = new Session(player.method_5667(), pos.method_10062(), x, y, z, yaw);
        SESSIONS.put(player.method_5667(), session);

        player.method_5848();
        player.method_5875(true);
        player.method_18799(class_243.field_1353);
        player.method_48105(world, x, y, z, java.util.Set.of(), yaw, cameraPitch);
        player.method_18380(class_4050.field_18079);
        player.field_6017 = 0.0f;


        ModPackets.sendOpenTable(player, session.tablePos, session.yaw);
        ModPackets.sendSync(player);
        return true;
    }

    /** Игрок встаёт со стола (закрыл меню / отмена). */
    public static void standUp(class_3222 player) {
        Session session = SESSIONS.remove(player.method_5667());
        if (session == null) {
            return;
        }
        release(player, session);
        OperatingTableBlock.setLit(player.method_51469(), session.tablePos, false);
    }

    private static void release(class_3222 player, Session session) {
        player.method_5875(false);
        player.method_18380(class_4050.field_18076);
        if (!player.method_31481() && !player.method_7325()) {
            player.method_48105(player.method_51469(), session.x, session.y, session.z,
                    java.util.Set.of(), session.yaw, 0.0f);
        }
    }

    // ------------------------------------------------------------------
    //  Операция
    // ------------------------------------------------------------------

    public static void requestInstall(class_3222 player, class_2338 pos, String partName) {
        Session session = SESSIONS.get(player.method_5667());
        if (session == null || !session.tablePos.equals(pos) || session.operating) {
            ModPackets.sendSurgeryEnd(player, "", false);
            return;
        }
        CyberPart part = CyberParts.byName(partName);
        if (part == null) {
            ModPackets.sendSurgeryEnd(player, "", false);
            return;
        }
        if (CyberData.has(player, part.slot())) {
            player.method_7353(class_2561.method_43471("redcyber.msg.already_installed"), true);
            ModPackets.sendSurgeryEnd(player, "", false);
            return;
        }
        if (!hasComponents(player, part)) {
            player.method_7353(class_2561.method_43471("redcyber.msg.missing_components"), true);
            ModPackets.sendSurgeryEnd(player, "", false);
            return;
        }

        consumeComponents(player, part);

        session.partName = part.name();
        session.operating = true;
        session.duration = SURGERY_DURATION;
        session.elapsed = 0;

        class_3218 world = player.method_51469();
        OperatingTableBlock.setLit(world, pos, true);
        world.method_8396(null, pos, class_3417.field_14703, class_3419.field_15245, 0.9f, 0.6f);
        world.method_8396(null, pos, class_3417.field_15228, class_3419.field_15245, 0.7f, 0.8f);

        ModPackets.sendSurgeryStart(player, part.name(), session.duration);
    }

    /** Тик сервера: отсчёт операции и проверка валидности сессий. */
    public static void tick(MinecraftServer server) {
        if (SESSIONS.isEmpty()) {
            return;
        }
        List<UUID> toFinish = new ArrayList<>();
        Iterator<Map.Entry<UUID, Session>> it = SESSIONS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Session> entry = it.next();
            Session session = entry.getValue();
            class_3222 player = server.method_3760().method_14602(session.playerId);

            if (player == null || player.method_31481() || player.method_29504()) {
                it.remove();
                continue;
            }
            class_3218 world = player.method_51469();
            class_2680 tableState = world.method_8320(session.tablePos);
            if (!(tableState.method_26204() instanceof OperatingTableBlock)) {
                // Стол сломали — прекращаем операцию.
                it.remove();
                if (session.operating) {
                    ModPackets.sendSurgeryEnd(player, "", false);
                }
                player.method_5875(false);
                player.method_18380(class_4050.field_18076);
                continue;
            }

            if (!session.operating) {
                continue;
            }

            session.elapsed++;
            tickSurgeryEffects(world, session, player);

            if (session.elapsed >= session.duration) {
                toFinish.add(session.playerId);
            }
        }

        for (UUID id : toFinish) {
            finishSurgery(server, id);
        }
    }

    private static void tickSurgeryEffects(class_3218 world, Session session, class_3222 player) {
        int e = session.elapsed;
        double x = session.x;
        double y = session.y + 0.35;
        double z = session.z;

        if (e % 12 == 0) {
            world.method_14199(class_2398.field_29644, x, y, z, 6, 0.35, 0.12, 0.35, 0.02);
        }
        if (e % 20 == 10) {
            world.method_8396(null, session.tablePos, class_3417.field_19199,
                    class_3419.field_15245, 0.45f, 1.6f);
        }
        if (e == 20) {
            world.method_8396(null, session.tablePos, class_3417.field_14559, class_3419.field_15245, 0.7f, 0.7f);
        }
        if (e == 60) {
            world.method_8396(null, session.tablePos, class_3417.field_23116,
                    class_3419.field_15245, 0.8f, 1.3f);
        }
        if (e == session.duration - 25) {
            world.method_8396(null, session.tablePos, class_3417.field_14891,
                    class_3419.field_15245, 0.9f, 1.1f);
        }
        if (e % 4 == 0) {
            player.method_18799(class_243.field_1353);
        }
    }

    private static void finishSurgery(MinecraftServer server, UUID playerId) {
        Session session = SESSIONS.remove(playerId);
        if (session == null) {
            return;
        }
        class_3222 player = server.method_3760().method_14602(playerId);
        if (player == null) {
            return;
        }
        CyberPart part = CyberParts.byName(session.partName);
        if (part == null) {
            release(player, session);
            return;
        }

        CyberData.install(player, part);
        CyberEffects.refresh(player);

        class_3218 world = player.method_51469();
        OperatingTableBlock.setLit(world, session.tablePos, false);
        world.method_8396(null, session.tablePos, class_3417.field_14703, class_3419.field_15245, 1.0f, 1.4f);
        world.method_8396(null, session.tablePos, class_3417.field_14709, class_3419.field_15248, 0.6f, 1.6f);
        world.method_14199(class_2398.field_29644, session.x, session.y + 0.4, session.z, 40, 0.5, 0.4, 0.5, 0.08);

        release(player, session);
        ModPackets.sendSurgeryEnd(player, part.name(), true);
        ModPackets.sendSync(player);
        player.method_7353(class_2561.method_43469("redcyber.msg.installed", part.item().method_7848()), false);
    }

    // ------------------------------------------------------------------
    //  Тик игрока (вызывается из миксина PlayerEntity)
    // ------------------------------------------------------------------

    public static void onPlayerTick(class_1657 player) {
        Session session = SESSIONS.get(player.method_5667());
        if (session == null) {
            return;
        }
        player.method_18380(class_4050.field_18079);
        player.method_5875(true);
        player.method_18799(class_243.field_1353);
        if (player.method_5649(session.x, session.y, session.z) > 0.0025) {
            player.method_5859(session.x, session.y, session.z);
        }
    }

    /** Игрок вышел — сессию закрываем без телепорта. */
    public static void onDisconnect(class_1657 player) {
        Session session = SESSIONS.remove(player.method_5667());
        if (session != null) {
            player.method_5875(false);
            player.method_18380(class_4050.field_18076);
        }
    }

    public static boolean isBusy(class_1657 player) {
        return SESSIONS.containsKey(player.method_5667());
    }

    // ------------------------------------------------------------------
    //  Компоненты
    // ------------------------------------------------------------------

    public static int count(class_1657 player, class_1792 item) {
        int total = 0;
        for (class_1799 stack : player.method_31548().field_7547) {
            if (stack.method_31574(item)) {
                total += stack.method_7947();
            }
        }
        for (class_1799 stack : player.method_31548().field_7544) {
            if (stack.method_31574(item)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    public static boolean hasComponents(class_1657 player, CyberPart part) {
        for (Map.Entry<class_1792, Integer> entry : part.components().entrySet()) {
            if (count(player, entry.getKey()) < entry.getValue()) {
                return false;
            }
        }
        return true;
    }

    private static void consumeComponents(class_1657 player, CyberPart part) {
        for (Map.Entry<class_1792, Integer> entry : part.components().entrySet()) {
            removeItems(player, entry.getKey(), entry.getValue());
        }
        if (player instanceof class_3222 serverPlayer) {
            serverPlayer.field_7512.method_34252();
            serverPlayer.field_7498.method_34252();
        }
    }

    private static void removeItems(class_1657 player, class_1792 item, int amount) {
        int left = amount;
        for (class_1799 stack : player.method_31548().field_7547) {
            if (left <= 0) {
                break;
            }
            if (stack.method_31574(item)) {
                int take = Math.min(left, stack.method_7947());
                stack.method_7934(take);
                left -= take;
            }
        }
        for (class_1799 stack : player.method_31548().field_7544) {
            if (left <= 0) {
                break;
            }
            if (stack.method_31574(item)) {
                int take = Math.min(left, stack.method_7947());
                stack.method_7934(take);
                left -= take;
            }
        }
    }
}
