package com.redcyber.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

/** Редстоуновый компонент: обычный предмет с описанием в подсказке. */
public class ComponentItem extends class_1792 {
    public ComponentItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471(this.method_7876() + ".desc").method_27692(class_124.field_1080));
        super.method_7851(stack, context, tooltip, type);
    }
}
