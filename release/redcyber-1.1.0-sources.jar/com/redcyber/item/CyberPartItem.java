package com.redcyber.item;

import com.redcyber.core.CyberSlot;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

/**
 * Кибернетический имплант. Сам предмет — это "спецификация": установить его
 * можно только на операционном столе, потратив редстоуновые компоненты.
 */
public class CyberPartItem extends class_1792 {
    private final CyberSlot slot;

    public CyberPartItem(CyberSlot slot, class_1793 settings) {
        super(settings);
        this.slot = slot;
    }

    public CyberSlot slot() {
        return this.slot;
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        String base = this.method_7876();
        tooltip.add(class_2561.method_43469("redcyber.tooltip.slot", this.slot.displayName()).method_27692(class_124.field_1063));
        tooltip.add(class_2561.method_43471(base + ".effect").method_27692(class_124.field_1060));
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43471(base + ".desc").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43471("redcyber.tooltip.install_hint").method_27695(class_124.field_1079, class_124.field_1056));
        super.method_7851(stack, context, tooltip, type);
    }
}
