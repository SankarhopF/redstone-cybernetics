package com.redcyber.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

/** Предмет операционного стола (с подсказкой, как им пользоваться). */
public class OperatingTableItem extends class_1747 {
    public OperatingTableItem(class_2248 block, class_1793 settings) {
        super(block, settings);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471(this.method_7876() + ".desc").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43471(this.method_7876() + ".usage").method_27695(class_124.field_1079, class_124.field_1056));
        super.method_7851(stack, context, tooltip, type);
    }
}
