package com.redcyber.block;

import com.redcyber.registry.ModBlockEntities;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

/** Блок-энтити операционного стола (держит состояние стола). */
public class OperatingTableBlockEntity extends class_2586 {
    public OperatingTableBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.OPERATING_TABLE, pos, state);
    }
}
