package com.redcyber.block;

import com.mojang.serialization.MapCodec;
import com.redcyber.core.SurgeryManager;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

/**
 * Операционный стол. По нажатию игрок ложится на него, камера уходит в третье лицо,
 * а клиенту отправляется пакет на открытие меню имплантации.
 */
public class OperatingTableBlock extends class_2237 {
    public static final MapCodec<OperatingTableBlock> field_46280 = method_54094(OperatingTableBlock::new);
    public static final class_2746 LIT = class_2746.method_11825("lit");

    /** Высота рабочей поверхности стола (14/16 блока) — на ней лежит игрок. */
    public static final double SURFACE_HEIGHT = 14.0 / 16.0;

    private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 14.0, 16.0);

    public OperatingTableBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(LIT, Boolean.FALSE));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(LIT);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new OperatingTableBlockEntity(pos, state);
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.method_8608()) {
            return class_1269.field_5812;
        }
        if (!(player instanceof class_3222 serverPlayer)) {
            return class_1269.field_5811;
        }
        boolean started = SurgeryManager.startSession(serverPlayer, pos);
        return started ? class_1269.field_5812 : class_1269.field_21466;
    }

    /** Включает/выключает подсветку стола (во время операции). */
    public static void setLit(class_1937 world, class_2338 pos, boolean lit) {
        class_2680 state = world.method_8320(pos);
        if (state.method_26204() instanceof OperatingTableBlock && state.method_11654(LIT) != lit) {
            world.method_8652(pos, state.method_11657(LIT, lit), class_2248.field_31036);
        }
    }
}
