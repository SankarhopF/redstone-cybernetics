package com.redcyber.client;

import com.redcyber.core.CyberPart;
import com.redcyber.core.CyberParts;
import com.redcyber.core.CyberSlot;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3532;

/** Состояние идущей операции на клиенте (для анимации/оверлея). */
public final class ClientSurgeryState {
    private static String activePart = null;
    private static CyberSlot activeSlot = null;
    private static int duration = 1;
    private static int ticks = 0;

    private ClientSurgeryState() {
    }

    public static void start(String part, int durationTicks) {
        activePart = part;
        var def = CyberParts.byName(part);
        activeSlot = def == null ? null : def.slot();
        duration = Math.max(1, durationTicks);
        ticks = 0;
    }

    public static void clear() {
        activePart = null;
        activeSlot = null;
        ticks = 0;
    }

    public static void clientTick() {
        if (activePart != null) {
            ticks++;
        }
    }

    public static boolean active() {
        return activePart != null;
    }

    public static String part() {
        return activePart;
    }

    public static float progress() {
        return class_3532.method_15363(ticks / (float) duration, 0.0f, 1.0f);
    }

    /** Слот, который сейчас меняют у этого существа (для анимации модели). */
    public static CyberSlot animationSlot(class_1309 entity) {
        if (activePart == null) {
            return null;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1724 != entity) {
            return null;
        }
        return activeSlot;
    }
}
