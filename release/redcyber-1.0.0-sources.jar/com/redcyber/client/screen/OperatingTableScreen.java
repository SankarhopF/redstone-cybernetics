package com.redcyber.client.screen;

import com.redcyber.client.CameraRig;
import com.redcyber.client.ClientCyberData;
import com.redcyber.core.CyberPart;
import com.redcyber.core.CyberParts;
import com.redcyber.net.ModPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_6382;
import net.minecraft.class_746;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Меню операционного стола.
 *
 * Фон (мир) размывается настоящим vanilla-блюром, панель меню при этом остаётся
 * полностью чёткой. Слева — список имплантов, справа — что нужно для операции
 * и сколько компонентов уже есть в инвентаре.
 */
public class OperatingTableScreen extends class_437 {
    private static final int PANEL_W = 384;
    private static final int PANEL_H = 240;

    private static final int COL_PANEL = 0xF01B2027;
    private static final int COL_PANEL_DARK = 0xF014171C;
    private static final int COL_BORDER = 0xFF39424D;
    private static final int COL_ACCENT = 0xFFE02231;
    private static final int COL_TEXT = 0xFFF2F5F7;
    private static final int COL_MUTED = 0xFF97A1AC;
    private static final int COL_OK = 0xFF4CE07A;
    private static final int COL_BAD = 0xFFE04A4A;
    private static final int COL_HEADER = 0xFFB3121B;

    private final class_2338 tablePos;
    private final List<CyberPart> parts = new ArrayList<>(CyberParts.all());
    private final List<PartRow> rows = new ArrayList<>();

    private int selected = 0;
    private int panelX;
    private int panelY;
    private class_4185 installButton;
    private String pendingPart = null;
    private class_2561 status = null;
    private boolean statusBad = false;
    private boolean leavingForSurgery = false;

    public OperatingTableScreen(class_2338 tablePos) {
        super(class_2561.method_43471("redcyber.screen.table.title"));
        this.tablePos = tablePos;
    }

    // ------------------------------------------------------------------
    //  Инициализация виджетов
    // ------------------------------------------------------------------

    @Override
    protected void method_25426() {
        this.panelX = (this.field_22789 - PANEL_W) / 2;
        this.panelY = (this.field_22790 - PANEL_H) / 2;
        this.rows.clear();

        int rowX = this.panelX + 12;
        int rowY = this.panelY + 36;
        for (int i = 0; i < this.parts.size(); i++) {
            PartRow row = new PartRow(this, i, rowX, rowY + i * 28, 178, 26);
            this.rows.add(row);
            this.method_37063(row);
        }

        this.installButton = class_4185.method_46430(class_2561.method_43471("redcyber.screen.table.operate"), b -> this.confirm())
                .method_46434(this.panelX + 200, this.panelY + PANEL_H - 32, 172, 20)
                .method_46431();
        this.method_37063(this.installButton);

        this.method_37063(class_4185.method_46430(class_2561.method_43471("redcyber.screen.table.leave"), b -> this.method_25419())
                .method_46434(this.panelX + 12, this.panelY + PANEL_H - 32, 120, 20)
                .method_46431());

        this.updateState();
    }

    // ------------------------------------------------------------------
    //  Фон: блюр мира + затемнение + панель
    // ------------------------------------------------------------------

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Настоящее размытие мира (тот же эффект, что у ванильных меню).
        this.method_57734(delta);
        // Затемнение, чтобы панель читалась.
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0xB0000000, 0xE0000000);

        this.drawPanel(context);
        this.drawDetails(context);
    }

    private void drawPanel(class_332 context) {
        int x = this.panelX;
        int y = this.panelY;

        context.method_25294(x - 3, y - 3, x + PANEL_W + 3, y + PANEL_H + 3, 0x80000000);
        context.method_25294(x, y, x + PANEL_W, y + PANEL_H, COL_PANEL);
        context.method_49601(x, y, PANEL_W, PANEL_H, COL_BORDER);
        context.method_25294(x, y, x + PANEL_W, y + 3, COL_HEADER);

        context.method_25294(x + 8, y + 32, x + 196, y + 204, COL_PANEL_DARK);
        context.method_25294(x + 196, y + 32, x + PANEL_W - 8, y + 204, COL_PANEL_DARK);
        context.method_25294(x + 10, y + 28, x + PANEL_W - 10, y + 29, COL_BORDER);

        class_327 tr = this.field_22793;
        context.method_51439(tr, class_2561.method_43471("redcyber.screen.table.title").method_27692(class_124.field_1067),
                x + 12, y + 11, 0xFFFFFFFF, false);
        class_2561 sub = class_2561.method_43471("redcyber.screen.table.subtitle");
        context.method_51439(tr, sub, x + PANEL_W - 12 - tr.method_27525(sub), y + 11, COL_MUTED, false);
    }

    private void drawDetails(class_332 context) {
        class_327 tr = this.field_22793;
        CyberPart part = this.parts.get(this.selected);
        int rx = this.panelX + 200;
        int ry = this.panelY + 40;
        boolean installed = ClientCyberData.has(part.slot());

        context.method_51439(tr, part.item().method_7848().method_27661().method_27692(class_124.field_1067), rx, ry, COL_TEXT, false);
        ry += 13;
        context.method_51439(tr, class_2561.method_43469("redcyber.screen.table.slot", part.slot().displayName()),
                rx, ry, COL_MUTED, false);
        ry += 14;

        List<class_5481> wrapped = tr.method_1728(class_2561.method_43471(part.effectKey()), 172);
        for (int i = 0; i < Math.min(3, wrapped.size()); i++) {
            context.method_51430(tr, wrapped.get(i), rx, ry + i * 10, COL_OK, false);
        }
        ry += Math.min(3, wrapped.size()) * 10 + 8;

        context.method_51439(tr, class_2561.method_43471("redcyber.screen.table.components").method_27692(class_124.field_1067),
                rx, ry, COL_HEADER, false);
        ry += 13;

        for (Map.Entry<class_1792, Integer> entry : part.components().entrySet()) {
            int have = this.countInInventory(entry.getKey());
            int need = entry.getValue();
            boolean enough = have >= need;
            context.method_51427(new class_1799(entry.getKey()), rx, ry - 4);
            context.method_51439(tr, entry.getKey().method_7848(), rx + 20, ry, enough ? COL_TEXT : COL_BAD, false);
            String counter = have + "/" + need;
            context.method_51433(tr, counter, rx + 172 - tr.method_1727(counter), ry, enough ? COL_OK : COL_BAD, false);
            ry += 20;
        }

        if (installed) {
            context.method_51439(tr, class_2561.method_43471("redcyber.screen.table.already"), rx, this.panelY + 196, COL_OK, false);
        } else if (this.status != null) {
            context.method_51439(tr, this.status, rx, this.panelY + 196, this.statusBad ? COL_BAD : COL_MUTED, false);
        }
    }

    // ------------------------------------------------------------------
    //  Логика
    // ------------------------------------------------------------------

    private void select(int index) {
        if (index >= 0 && index < this.parts.size()) {
            this.selected = index;
            this.status = null;
            this.statusBad = false;
            this.updateState();
        }
    }

    private CyberPart selectedPart() {
        return this.parts.get(this.selected);
    }

    private boolean canAfford(CyberPart part) {
        for (Map.Entry<class_1792, Integer> entry : part.components().entrySet()) {
            if (this.countInInventory(entry.getKey()) < entry.getValue()) {
                return false;
            }
        }
        return true;
    }

    private int countInInventory(class_1792 item) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return 0;
        }
        int total = 0;
        for (class_1799 stack : player.method_31548().field_7547) {
            if (stack.method_31574(item)) {
                total += stack.method_7947();
            }
        }
        for (class_1799 stack : player.method_31548().field_7544) {
            if (stack.method_31574(item)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    private void updateState() {
        CyberPart part = this.selectedPart();
        boolean installed = ClientCyberData.has(part.slot());
        boolean affordable = this.canAfford(part);
        boolean pending = this.pendingPart != null;

        if (this.installButton != null) {
            this.installButton.field_22763 = !installed && affordable && !pending;
            this.installButton.method_25355(installed
                    ? class_2561.method_43471("redcyber.screen.table.installed")
                    : pending
                    ? class_2561.method_43471("redcyber.screen.table.pending")
                    : class_2561.method_43471("redcyber.screen.table.operate"));
        }
        if (!pending && !installed) {
            if (!affordable) {
                this.status = class_2561.method_43471("redcyber.screen.table.need_more");
                this.statusBad = true;
            } else {
                this.status = class_2561.method_43471("redcyber.screen.table.ready");
                this.statusBad = false;
            }
        }
    }

    private void confirm() {
        if (this.pendingPart != null) {
            return;
        }
        CyberPart part = this.selectedPart();
        if (ClientCyberData.has(part.slot()) || !this.canAfford(part)) {
            return;
        }
        this.pendingPart = part.name();
        this.status = class_2561.method_43471("redcyber.screen.table.pending");
        this.statusBad = false;
        this.updateState();
        if (ClientPlayNetworking.canSend(ModPackets.InstallPartC2S.ID)) {
            ClientPlayNetworking.send(new ModPackets.InstallPartC2S(this.tablePos, part.name()));
        }
    }

    // ------------------------------------------------------------------
    //  События от сетевого слоя
    // ------------------------------------------------------------------

    /** Сервер начал операцию — этот экран уступает место анимации. */
    public void onSurgeryStarted(String partName) {
        this.leavingForSurgery = true;
    }

    /** Сервер отказал (не хватает компонентов и т.п.). */
    public void onInstallRejected() {
        this.pendingPart = null;
        this.status = class_2561.method_43471("redcyber.msg.missing_components");
        this.statusBad = true;
        this.updateState();
    }

    @Override
    public void method_25432() {
        if (!this.leavingForSurgery) {
            if (ClientPlayNetworking.canSend(ModPackets.CloseTableC2S.ID)) {
                ClientPlayNetworking.send(new ModPackets.CloseTableC2S());
            }
            CameraRig.restore();
        }
        super.method_25432();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // ------------------------------------------------------------------
    //  Строка списка имплантов
    // ------------------------------------------------------------------

    private static class PartRow extends class_339 {
        private final OperatingTableScreen parent;
        private final int index;

        PartRow(OperatingTableScreen parent, int index, int x, int y, int width, int height) {
            super(x, y, width, height, parent.parts.get(index).item().method_7848());
            this.parent = parent;
            this.index = index;
        }

        @Override
        protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
            class_327 tr = class_310.method_1551().field_1772;
            CyberPart part = this.parent.parts.get(this.index);
            boolean selected = this.parent.selected == this.index;
            boolean installed = ClientCyberData.has(part.slot());

            int x = this.method_46426();
            int y = this.method_46427();
            int w = this.method_25368();
            int h = this.method_25364();

            int bg = selected ? 0xFF2B3440 : (this.method_49606() ? 0xFF232B34 : 0xFF1A1F26);
            context.method_25294(x, y, x + w, y + h, bg);
            context.method_49601(x, y, w, h, selected ? COL_ACCENT : COL_BORDER);
            context.method_51427(part.item().method_7854(), x + 5, y + 5);
            context.method_51439(tr, part.item().method_7848(), x + 26, y + 5, installed ? COL_MUTED : COL_TEXT, false);
            context.method_51439(tr, part.slot().displayName(), x + 26, y + 15, COL_MUTED, false);
            if (installed) {
                context.method_51433(tr, "\u2714", x + w - 14, y + 9, COL_OK, false);
            }
        }

        @Override
        public void method_25348(double mouseX, double mouseY) {
            this.parent.select(this.index);
            this.parent.updateState();
        }

        @Override
        protected void method_47399(class_6382 builder) {
            this.method_37021(builder);
        }
    }
}
