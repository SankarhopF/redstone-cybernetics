package com.redcyber.client;

import net.minecraft.class_310;
import net.minecraft.class_5498;

/** Переключение камеры в третье лицо на время работы со столом. */
public final class CameraRig {
    private static class_5498 saved = null;

    private CameraRig() {
    }

    public static void enterThirdPerson() {
        class_310 client = class_310.method_1551();
        if (saved == null) {
            saved = client.field_1690.method_31044();
        }
        client.field_1690.method_31043(class_5498.field_26666);
    }

    public static void restore() {
        class_310 client = class_310.method_1551();
        client.field_1690.method_31043(saved == null ? class_5498.field_26664 : saved);
        saved = null;
    }
}
