package com.redcyber.net;

import com.redcyber.RedCyber;
import com.redcyber.core.CyberData;
import com.redcyber.core.SurgeryManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Все сетевые пакеты мода. */
public final class ModPackets {
    private ModPackets() {
    }

    // ------------------------------------------------------------------
    //  S2C
    // ------------------------------------------------------------------

    /** Сервер -> клиент: игрок лёг на стол, открываем меню имплантации. */
    public record OpenTableS2C(class_2338 pos) implements class_8710 {
        public static final class_9154<OpenTableS2C> ID = new class_9154<>(RedCyber.id("open_table"));
        public static final class_9139<class_9129, OpenTableS2C> CODEC =
                class_9139.method_56434(class_2338.field_48404, OpenTableS2C::pos, OpenTableS2C::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** Сервер -> клиент: синхронизация установленных имплантов ("EYE=cyber_eye,..."). */
    public record SyncCyberS2C(String data) implements class_8710 {
        public static final class_9154<SyncCyberS2C> ID = new class_9154<>(RedCyber.id("sync_cyber"));
        public static final class_9139<class_9129, SyncCyberS2C> CODEC =
                class_9139.method_56434(class_9135.field_48554, SyncCyberS2C::data, SyncCyberS2C::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** Сервер -> клиент: операция началась, играем анимацию. */
    public record SurgeryStartS2C(String part, int duration) implements class_8710 {
        public static final class_9154<SurgeryStartS2C> ID = new class_9154<>(RedCyber.id("surgery_start"));
        public static final class_9139<class_9129, SurgeryStartS2C> CODEC = class_9139.method_56435(
                class_9135.field_48554, SurgeryStartS2C::part,
                class_9135.field_48550, SurgeryStartS2C::duration,
                SurgeryStartS2C::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** Сервер -> клиент: операция завершена (или отменена, если part пустой). */
    public record SurgeryEndS2C(String part, boolean success) implements class_8710 {
        public static final class_9154<SurgeryEndS2C> ID = new class_9154<>(RedCyber.id("surgery_end"));
        public static final class_9139<class_9129, SurgeryEndS2C> CODEC = class_9139.method_56435(
                class_9135.field_48554, SurgeryEndS2C::part,
                class_9135.field_48547, SurgeryEndS2C::success,
                SurgeryEndS2C::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    //  C2S
    // ------------------------------------------------------------------

    /** Клиент -> сервер: "я хочу поставить этот имплант". */
    public record InstallPartC2S(class_2338 pos, String part) implements class_8710 {
        public static final class_9154<InstallPartC2S> ID = new class_9154<>(RedCyber.id("install_part"));
        public static final class_9139<class_9129, InstallPartC2S> CODEC = class_9139.method_56435(
                class_2338.field_48404, InstallPartC2S::pos,
                class_9135.field_48554, InstallPartC2S::part,
                InstallPartC2S::new);

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** Клиент -> сервер: игрок встаёт со стола. */
    public record CloseTableC2S() implements class_8710 {
        public static final class_9154<CloseTableC2S> ID = new class_9154<>(RedCyber.id("close_table"));
        public static final class_9139<class_9129, CloseTableC2S> CODEC =
                class_9139.method_56431(new CloseTableC2S());

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    // ------------------------------------------------------------------
    //  Регистрация и отправка
    // ------------------------------------------------------------------

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(OpenTableS2C.ID, OpenTableS2C.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncCyberS2C.ID, SyncCyberS2C.CODEC);
        PayloadTypeRegistry.playS2C().register(SurgeryStartS2C.ID, SurgeryStartS2C.CODEC);
        PayloadTypeRegistry.playS2C().register(SurgeryEndS2C.ID, SurgeryEndS2C.CODEC);

        PayloadTypeRegistry.playC2S().register(InstallPartC2S.ID, InstallPartC2S.CODEC);
        PayloadTypeRegistry.playC2S().register(CloseTableC2S.ID, CloseTableC2S.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(InstallPartC2S.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> SurgeryManager.requestInstall(player, payload.pos(), payload.part()));
        });

        ServerPlayNetworking.registerGlobalReceiver(CloseTableC2S.ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> SurgeryManager.standUp(player));
        });
    }

    public static void sendOpenTable(class_3222 player, class_2338 pos) {
        ServerPlayNetworking.send(player, new OpenTableS2C(pos));
    }

    public static void sendSync(class_3222 player) {
        ServerPlayNetworking.send(player, new SyncCyberS2C(CyberData.encode(CyberData.parts(player))));
    }

    public static void sendSurgeryStart(class_3222 player, String part, int duration) {
        ServerPlayNetworking.send(player, new SurgeryStartS2C(part, duration));
    }

    public static void sendSurgeryEnd(class_3222 player, String part, boolean success) {
        ServerPlayNetworking.send(player, new SurgeryEndS2C(part, success));
    }
}
