package com.redcyber.core;

import com.redcyber.RedCyber;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

/** Применяет эффекты установленных имплантов к игроку. */
public final class CyberEffects {
    private CyberEffects() {
    }

    /** Описание одного модификатора атрибута. */
    private record Mod(class_6880<class_1320> attribute, double value) {
    }

    private static final Map<CyberSlot, List<Mod>> MODIFIERS = new EnumMap<>(CyberSlot.class);

    static {
        MODIFIERS.put(CyberSlot.EYE, List.of(
                new Mod(class_5134.field_47758, 1.0),
                new Mod(class_5134.field_47759, 1.0)));

        MODIFIERS.put(CyberSlot.ARM, List.of(
                new Mod(class_5134.field_23721, 2.0),
                new Mod(class_5134.field_49076, 0.4),
                new Mod(class_5134.field_51581, 2.0)));

        MODIFIERS.put(CyberSlot.LEG, List.of(
                new Mod(class_5134.field_23719, 0.035),
                new Mod(class_5134.field_47761, 0.6),
                new Mod(class_5134.field_49079, 2.0),
                new Mod(class_5134.field_23728, 0.06)));

        MODIFIERS.put(CyberSlot.HEART, List.of(
                new Mod(class_5134.field_23716, 6.0),
                new Mod(class_5134.field_23718, 0.15)));

        MODIFIERS.put(CyberSlot.LUNG, List.of(
                new Mod(class_5134.field_51583, 4.0),
                new Mod(class_5134.field_51576, 1.0)));

        MODIFIERS.put(CyberSlot.SPINE, List.of(
                new Mod(class_5134.field_49077, -0.9),
                new Mod(class_5134.field_23718, 0.35),
                new Mod(class_5134.field_51580, 0.3)));
    }

    /** Пересчитывает все модификаторы и статус-эффекты по текущему набору имплантов. */
    public static void refresh(class_3222 player) {
        Map<CyberSlot, String> installed = CyberData.parts(player);

        for (CyberSlot slot : CyberSlot.values()) {
            List<Mod> mods = MODIFIERS.getOrDefault(slot, List.of());
            for (int i = 0; i < mods.size(); i++) {
                Mod mod = mods.get(i);
                class_1324 instance = player.method_5996(mod.attribute());
                if (instance == null) {
                    continue;
                }
                var id = RedCyber.id("implant_" + slot.lowerName() + "_" + i);
                instance.method_6200(id);
                if (installed.containsKey(slot)) {
                    instance.method_26837(new class_1322(id, mod.value(),
                            class_1322.class_1323.field_6328));
                }
            }
        }

        if (installed.containsKey(CyberSlot.EYE)) {
            player.method_6092(new class_1293(class_1294.field_5925, 500, 0, true, false, false));
        }
        if (installed.containsKey(CyberSlot.LUNG)) {
            player.method_6092(new class_1293(class_1294.field_5923, 500, 0, true, false, false));
        }
        if (installed.containsKey(CyberSlot.HEART)) {
            player.method_6092(new class_1293(class_1294.field_5924, 120, 0, true, false, true));
        }
    }

    /** Краткая строка для тултипа/меню. */
    public static List<String> modifierIds(CyberSlot slot) {
        List<String> ids = new ArrayList<>();
        List<Mod> mods = MODIFIERS.getOrDefault(slot, List.of());
        for (int i = 0; i < mods.size(); i++) {
            ids.add("implant_" + slot.lowerName() + "_" + i);
        }
        return ids;
    }
}
