package com.redcyber.mixin.client;

import com.redcyber.client.ClientSurgeryState;
import com.redcyber.core.CyberSlot;
import net.minecraft.class_1309;
import net.minecraft.class_3532;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Анимация во время операции: у лежащего игрока подёргивается та часть тела,
 * которую меняют (рука, нога, голова и т.д.), плюс лёгкие «судороги» корпуса.
 */
@Mixin(class_591.class)
public abstract class PlayerEntityModelMixin extends class_572<class_1309> {

    public PlayerEntityModelMixin(class_630 root, boolean thinArms) {
        super(root);
    }

    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void redcyber$animateSurgery(class_1309 entity, float limbAngle, float limbDistance,
                                         float animationProgress, float headYaw, float headPitch, CallbackInfo ci) {
        CyberSlot slot = ClientSurgeryState.animationSlot(entity);
        if (slot == null) {
            return;
        }

        float t = animationProgress;
        float twitch = class_3532.method_15374(t * 1.35f);
        float slow = class_3532.method_15374(t * 0.35f);

        switch (slot) {
            case ARM -> {
                this.field_3401.field_3654 = -1.35f + twitch * 0.45f;
                this.field_3401.field_3674 = 0.35f * class_3532.method_15374(t * 0.9f);
                this.field_27433.field_3654 = -0.25f + slow * 0.08f;
            }
            case LEG -> {
                this.field_3392.field_3654 = 0.55f * twitch;
                this.field_3392.field_3674 = 0.2f * slow;
                this.field_3397.field_3654 = -0.25f + slow * 0.06f;
            }
            case HEART -> {
                this.field_3391.field_3654 += 0.07f * class_3532.method_15374(t * 1.1f);
                this.field_3391.field_3674 = 0.05f * slow;
                this.field_3401.field_3654 = -0.3f + twitch * 0.2f;
                this.field_27433.field_3654 = -0.3f - twitch * 0.2f;
            }
            case EYE -> {
                this.field_3398.field_3675 = 0.22f * class_3532.method_15374(t * 0.8f);
                this.field_3398.field_3654 += 0.1f * twitch;
                this.field_3398.field_3674 = 0.08f * slow;
            }
            case LUNG -> {
                this.field_3391.field_3654 += 0.05f * class_3532.method_15374(t * 0.55f);
                this.field_3398.field_3675 = 0.06f * slow;
            }
            case SPINE -> {
                this.field_3391.field_3674 = 0.12f * class_3532.method_15374(t * 0.5f);
                this.field_3391.field_3675 += 0.05f * slow;
            }
        }

        // Обе руки чуть подрагивают в такт «операции».
        this.field_3401.field_3675 += 0.04f * twitch;
        this.field_27433.field_3675 -= 0.04f * twitch;
    }
}
