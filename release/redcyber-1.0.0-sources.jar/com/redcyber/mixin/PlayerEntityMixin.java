package com.redcyber.mixin;

import com.redcyber.core.CyberAccess;
import com.redcyber.core.CyberSlot;
import com.redcyber.core.SurgeryManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2520;

/**
 * Хранит установленные импланты в NBT игрока и держит игрока лежащим на столе,
 * пока открыта сессия операции.
 */
@Mixin(class_1657.class)
public abstract class PlayerEntityMixin implements CyberAccess {
    @Unique
    private Map<CyberSlot, String> redcyber$parts;

    @Override
    public Map<CyberSlot, String> redcyber$getParts() {
        if (this.redcyber$parts == null) {
            this.redcyber$parts = new EnumMap<>(CyberSlot.class);
        }
        return this.redcyber$parts;
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void redcyber$writeNbt(class_2487 nbt, CallbackInfo ci) {
        class_2487 tag = new class_2487();
        this.redcyber$getParts().forEach((slot, part) -> tag.method_10582(slot.lowerName(), part));
        nbt.method_10566("RedCyberParts", tag);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void redcyber$readNbt(class_2487 nbt, CallbackInfo ci) {
        Map<CyberSlot, String> parts = this.redcyber$getParts();
        parts.clear();
        if (nbt.method_10573("RedCyberParts", class_2520.field_33260)) {
            class_2487 tag = nbt.method_10562("RedCyberParts");
            for (CyberSlot slot : CyberSlot.values()) {
                String value = tag.method_10558(slot.lowerName());
                if (!value.isEmpty()) {
                    parts.put(slot, value);
                }
            }
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void redcyber$tick(CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        if (self.method_37908().method_8608()) {
            return;
        }
        SurgeryManager.onPlayerTick(self);
    }
}
